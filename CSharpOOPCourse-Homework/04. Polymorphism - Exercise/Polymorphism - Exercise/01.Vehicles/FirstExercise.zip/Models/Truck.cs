﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles.Models
{
    public class Truck : Vehicle
    {
        private const double IncreasedFuelConsumption = 1.6;

        public Truck(double fuelQuantity, double fuelConsumptionPerKm) : base(fuelQuantity, fuelConsumptionPerKm, IncreasedFuelConsumption)
        {
        }

        public override void RefuelVehicle(double amountOfFuel)
        {
            amountOfFuel = amountOfFuel * 0.95;
            this.FuelQuantity += amountOfFuel;
        }
    }
}
