﻿using Vehicles.Models.Interfaces;

namespace Vehicles.Models
{
    public abstract class Vehicle : IVehicle
    {
        private double increasedFuelConsumption;

        protected Vehicle(double fuelQuantity, double fuelConsumptionPerKm, double increasedFuelConsumption)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumptionPerKm = fuelConsumptionPerKm;
            this.increasedFuelConsumption = increasedFuelConsumption;
        }

        public double FuelQuantity { get; protected set; }

        public double FuelConsumptionPerKm { get; protected set; }

        public void DriveDistance(double distance)
        {
            double needFuel = (this.FuelConsumptionPerKm + this.increasedFuelConsumption) * distance;
            if (this.FuelQuantity - needFuel >= 0)
            {
                Console.WriteLine($"{this.GetType().Name} travelled {distance} km");
                this.FuelQuantity -= needFuel;
            }
            else
            {
                Console.WriteLine($"{this.GetType().Name} needs refueling");
            }
        }

        public abstract void RefuelVehicle(double amountOfFuel);

        public override string ToString() => $"{this.GetType().Name}: {this.FuelQuantity:F2}";
    }
}