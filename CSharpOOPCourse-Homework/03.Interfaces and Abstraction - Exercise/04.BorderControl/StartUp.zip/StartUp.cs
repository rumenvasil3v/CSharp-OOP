﻿using BorderControl.Core;

IEngine engine = new Engine();
engine.Run();