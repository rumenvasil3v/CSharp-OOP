using NUnit.Framework;

namespace Skeleton.Tests
{
    [TestFixture]
    public class AxeTests
    {
        private int initialDurabilityPoints;
        private int currentDurabilityPoints;
        private Axe axe;
        private Dummy dummyTarget;

        [SetUp]
        public void Initialize()
        {
            axe = new Axe(1, 5);
            initialDurabilityPoints = axe.DurabilityPoints;

            dummyTarget = new Dummy(18, 20);
        }


        [Test]
        public void When_AttackWithAxe_Weapon_ShouldLoseDurability()
        {
            axe.Attack(dummyTarget);
            currentDurabilityPoints = axe.DurabilityPoints;

            Assert.AreNotEqual(initialDurabilityPoints, currentDurabilityPoints);
        }

        [Test]
        public void When_AttackingWithBroken_Weapon_ExceptionShouldBeThrown()
        {
            while (axe.DurabilityPoints != 0)
            {
                axe.Attack(dummyTarget);
            }

            TestDelegate testDelegate = () => 
            {
                axe.Attack(dummyTarget);
            };

            Assert.Catch(testDelegate);
        }
    }
}